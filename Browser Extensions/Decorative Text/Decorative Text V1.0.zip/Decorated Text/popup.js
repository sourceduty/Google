document.getElementById('convertBtn').addEventListener('click', function() {
    var textInput = document.getElementById('textInput').value;
    var styleSelect = document.getElementById('styleSelect'); // Assuming you have a dropdown for style selection
    var style = styleSelect.value; // Get the selected style from the dropdown
    var asciiArt = convertToAscii(textInput, style);
    document.getElementById('asciiArt').value = asciiArt;
});

document.getElementById('copyBtn').addEventListener('click', function() {
    var asciiArt = document.getElementById('asciiArt');
    asciiArt.select();
    document.execCommand('copy');
});

function convertToAscii(text, style) {
    // Define unique mappings for each style
    const mappings = {
        fancy: {
            'A': '𝓐', 'B': '𝓑', 'C': '𝓒', 'D': '𝓓', 'E': '𝓔', 'F': '𝓕', 'G': '𝓖', 'H': '𝓗', 'I': '𝓘', 'J': '𝓙', 'K': '𝓚', 'L': '𝓛', 'M': '𝓜', 'N': '𝓝', 'O': '𝓞', 'P': '𝓟', 'Q': '𝓠', 'R': '𝓡', 'S': '𝓢', 'T': '𝓣', 'U': '𝓤', 'V': '𝓥', 'W': '𝓦', 'X': '𝓧', 'Y': '𝓨', 'Z': '𝓩'
        },
        block: {
            'A': '🄰', 'B': '🄱', 'C': '🄲', 'D': '🄳', 'E': '🄴', 'F': '🄵', 'G': '🄶', 'H': '🄷', 'I': '🄸', 'J': '🄹', 'K': '🄺', 'L': '🄻', 'M': '🄼', 'N': '🄽', 'O': '🄾', 'P': '🄿', 'Q': '🅀', 'R': '🅁', 'S': '🅂', 'T': '🅃', 'U': '🅄', 'V': '🅅', 'W': '🅆', 'X': '🅇', 'Y': '🅈', 'Z': '🅉'
        },
        gothic: {
            'A': '𝔄', 'B': '𝔅', 'C': 'ℭ', 'D': '𝔇', 'E': '𝔈', 'F': '𝔉', 'G': '𝔊', 'H': 'ℌ', 'I': 'ℑ', 'J': '𝔍', 'K': '𝔎', 'L': '𝔏', 'M': '𝔐', 'N': '𝔑', 'O': '𝔒', 'P': '𝔓', 'Q': '𝔔', 'R': 'ℜ', 'S': '𝔖', 'T': '𝔗', 'U': '𝔘', 'V': '𝔙', 'W': '𝔚', 'X': '𝔛', 'Y': '𝔜', 'Z': 'ℨ'
        }
        // Add more styles as needed
    };

    const asciiMap = mappings[style] || mappings['fancy']; // Use selected style, default to 'fancy'

    let asciiArt = '';
    for (let char of text.toUpperCase()) { // Convert to uppercase to match the mapping keys
        asciiArt += asciiMap[char] || char; // Use the mapped character or fallback to the original
    }

    return asciiArt;
}
