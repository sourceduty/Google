chrome.runtime.onInstalled.addListener(() => {
  console.log('Text to ASCII Art Converter extension installed.');
});
